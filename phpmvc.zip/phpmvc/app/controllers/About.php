<?php
class About{
    public function page(){
        echo 'About/page';
    }
}