<?php

class App{

    protected $ctrl = 'Home';
    protected $method = 'index';
    protected $params = [];

    public function __construct(){
        // var_dump($_GET);
        $url = $this->parseURL();
        
        //untuk menampilkan url pada dokumen menggunakan perintah vardam
        // var_dump($url);
        
        // if( file_exists('../app/controllers/'.$url[0].'.php') ){
        //     $this->ctrl = $url[0];

        //     unset($url[0]);
        //     var_dump($url);
        // }

        if(file_exists('../app/controllers/'.$url[0].'.php')){
            unset($url[0]);
        }

        require_once '../app/controllers/'.$this->ctrl.'.php';
        $this->ctrl = new $this->ctrl;

        //method
        if(isset($url[1])){
            if(method_exists($this->ctrl, $url[1])){
                $this->method = $url[1];
                unset($url[1]);
            }
        }

        //params
        if(!empty($url)){
            var_dump($url);
        }

    }


    public function parseURL(){
        if(isset($_GET['url'])){
            //untuk menghilangkan slash '/' terakhir pada url menggunkan perintah "rtrim"
            $url = rtrim($_GET['url'], '/');
            $url = filter_var($url, FILTER_SANITIZE_URL);
            
            //url dipecah berdasarkan '/' menggunakan perintah "explode"
            $url = explode('/', $url);

            return $url;
        }
    }
}
